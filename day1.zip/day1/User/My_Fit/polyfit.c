/*
 * File: polyfit.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 08-Jan-2021 09:44:36
 */

/* Include Files */
#include <string.h>
#include "rt_nonfinite.h"
#include "My_Fit.h"
#include "polyfit.h"
#include "xgeqp3.h"

/* Function Definitions */

/*
 * Arguments    : const float x[30]
 *                const float y[30]
 *                float p[3]
 * Return Type  : void
 */
void polyfit(const float x[30], const float y[30], float p[3])
{
  int k;
  float V[90];
  float tau[3];
  int jpvt[3];
  float B[30];
  float wj;
  int i0;
  int i;
  for (k = 0; k < 30; k++) {
    V[60 + k] = 1.0F;
    V[30 + k] = x[k];
    V[k] = x[k] * x[k];
  }

  xgeqp3(V, tau, jpvt);
  memcpy(&B[0], &y[0], 30U * sizeof(float));
  for (k = 0; k < 3; k++) {
    p[k] = 0.0F;
    if (tau[k] != 0.0F) {
      wj = B[k];
      i0 = k + 2;
      for (i = i0; i < 31; i++) {
        wj += V[(i + 30 * k) - 1] * B[i - 1];
      }

      wj *= tau[k];
      if (wj != 0.0F) {
        B[k] -= wj;
        i0 = k + 2;
        for (i = i0; i < 31; i++) {
          B[i - 1] -= V[(i + 30 * k) - 1] * wj;
        }
      }
    }
  }

  p[jpvt[0] - 1] = B[0];
  p[jpvt[1] - 1] = B[1];
  p[jpvt[2] - 1] = B[2];
  for (k = 2; k >= 0; k--) {
    p[jpvt[k] - 1] /= V[k + 30 * k];
    for (i = 0; i < k; i++) {
      p[jpvt[i] - 1] -= p[jpvt[k] - 1] * V[i + 30 * k];
    }
  }
}

/*
 * File trailer for polyfit.c
 *
 * [EOF]
 */
