/*
 * File: My_Fit.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 08-Jan-2021 09:44:36
 */

#ifndef MY_FIT_H
#define MY_FIT_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "My_Fit_types.h"

/* Function Declarations */
extern void My_Fit(const float x[30], const float y[30], float f[3]);

#endif

/*
 * File trailer for My_Fit.h
 *
 * [EOF]
 */
