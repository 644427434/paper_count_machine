/*
 * File: My_Fit.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 08-Jan-2021 09:44:36
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "My_Fit.h"
#include "polyfit.h"

/* Function Definitions */

/*
 * Arguments    : const float x[30]
 *                const float y[30]
 *                float f[3]
 * Return Type  : void
 */
void My_Fit(const float x[30], const float y[30], float f[3])
{
  polyfit(x, y, f);
}

/*
 * File trailer for My_Fit.c
 *
 * [EOF]
 */
