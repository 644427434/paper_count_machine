/*
 * File: My_Fit_types.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 08-Jan-2021 09:44:36
 */

#ifndef MY_FIT_TYPES_H
#define MY_FIT_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for My_Fit_types.h
 *
 * [EOF]
 */
