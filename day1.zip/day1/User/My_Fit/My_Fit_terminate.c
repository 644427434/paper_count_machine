/*
 * File: My_Fit_terminate.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 08-Jan-2021 09:44:36
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "My_Fit.h"
#include "My_Fit_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void My_Fit_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for My_Fit_terminate.c
 *
 * [EOF]
 */
