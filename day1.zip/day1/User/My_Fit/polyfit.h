/*
 * File: polyfit.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 08-Jan-2021 09:44:36
 */

#ifndef POLYFIT_H
#define POLYFIT_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "My_Fit_types.h"

/* Function Declarations */
extern void polyfit(const float x[30], const float y[30], float p[3]);

#endif

/*
 * File trailer for polyfit.h
 *
 * [EOF]
 */
