/*
 * File: xgeqp3.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 08-Jan-2021 09:44:36
 */

/* Include Files */
#include <math.h>
#include "rt_nonfinite.h"
#include <string.h>
#include "My_Fit.h"
#include "xgeqp3.h"
#include "xnrm2.h"

/* Function Declarations */
static float rt_hypotf_snf(float u0, float u1);

/* Function Definitions */

/*
 * Arguments    : float u0
 *                float u1
 * Return Type  : float
 */
static float rt_hypotf_snf(float u0, float u1)
{
  float y;
  float a;
  float b;
  a = fabsf(u0);
  b = fabsf(u1);
  if (a < b) {
    a /= b;
    y = b * sqrtf(a * a + 1.0F);
  } else if (a > b) {
    b /= a;
    y = a * sqrtf(b * b + 1.0F);
  } else if (rtIsNaNF(b)) {
    y = b;
  } else {
    y = a * 1.41421354F;
  }

  return y;
}

/*
 * Arguments    : float A[90]
 *                float tau[3]
 *                int jpvt[3]
 * Return Type  : void
 */
void xgeqp3(float A[90], float tau[3], int jpvt[3])
{
  int k;
  int iy;
  int i;
  float work[3];
  int ip1;
  float smax;
  int i_i;
  float scale;
  int kend;
  int pvt;
  int ix;
  float absxk;
  float vn1[3];
  float vn2[3];
  float t;
  int jA;
  int i1;
  int lastv;
  int lastc;
  bool exitg2;
  int exitg1;
  k = 1;
  for (iy = 0; iy < 3; iy++) {
    jpvt[iy] = 1 + iy;
    work[iy] = 0.0F;
    smax = 0.0F;
    scale = 1.29246971E-26F;
    kend = k + 29;
    for (pvt = k; pvt <= kend; pvt++) {
      absxk = fabsf(A[pvt - 1]);
      if (absxk > scale) {
        t = scale / absxk;
        smax = 1.0F + smax * t * t;
        scale = absxk;
      } else {
        t = absxk / scale;
        smax += t * t;
      }
    }

    smax = scale * sqrtf(smax);
    vn1[iy] = smax;
    vn2[iy] = smax;
    k += 30;
  }

  for (i = 0; i < 3; i++) {
    ip1 = i + 2;
    i_i = i + i * 30;
    kend = 3 - i;
    pvt = 1;
    if (3 - i > 1) {
      ix = i;
      smax = fabsf(vn1[i]);
      for (k = 2; k <= kend; k++) {
        ix++;
        scale = fabsf(vn1[ix]);
        if (scale > smax) {
          pvt = k;
          smax = scale;
        }
      }
    }

    pvt = (i + pvt) - 1;
    if (pvt != i) {
      ix = 30 * pvt;
      iy = 30 * i;
      for (k = 0; k < 30; k++) {
        smax = A[ix];
        A[ix] = A[iy];
        A[iy] = smax;
        ix++;
        iy++;
      }

      kend = jpvt[pvt];
      jpvt[pvt] = jpvt[i];
      jpvt[i] = kend;
      vn1[pvt] = vn1[i];
      vn2[pvt] = vn2[i];
    }

    absxk = A[i_i];
    kend = i_i + 2;
    tau[i] = 0.0F;
    smax = xnrm2(29 - i, A, i_i + 2);
    if (smax != 0.0F) {
      scale = rt_hypotf_snf(A[i_i], smax);
      if (A[i_i] >= 0.0F) {
        scale = -scale;
      }

      if (fabsf(scale) < 9.86076132E-32F) {
        pvt = -1;
        i1 = (i_i - i) + 30;
        do {
          pvt++;
          for (k = kend; k <= i1; k++) {
            A[k - 1] *= 1.01412048E+31F;
          }

          scale *= 1.01412048E+31F;
          absxk *= 1.01412048E+31F;
        } while (!(fabsf(scale) >= 9.86076132E-32F));

        scale = rt_hypotf_snf(absxk, xnrm2(29 - i, A, i_i + 2));
        if (absxk >= 0.0F) {
          scale = -scale;
        }

        tau[i] = (scale - absxk) / scale;
        smax = 1.0F / (absxk - scale);
        for (k = kend; k <= i1; k++) {
          A[k - 1] *= smax;
        }

        for (k = 0; k <= pvt; k++) {
          scale *= 9.86076132E-32F;
        }

        absxk = scale;
      } else {
        tau[i] = (scale - A[i_i]) / scale;
        smax = 1.0F / (A[i_i] - scale);
        i1 = (i_i - i) + 30;
        for (k = kend; k <= i1; k++) {
          A[k - 1] *= smax;
        }

        absxk = scale;
      }
    }

    A[i_i] = absxk;
    if (i + 1 < 3) {
      absxk = A[i_i];
      A[i_i] = 1.0F;
      jA = (i + (i + 1) * 30) + 1;
      if (tau[i] != 0.0F) {
        lastv = 30 - i;
        kend = (i_i - i) + 29;
        while ((lastv > 0) && (A[kend] == 0.0F)) {
          lastv--;
          kend--;
        }

        lastc = 1 - i;
        exitg2 = false;
        while ((!exitg2) && (lastc + 1 > 0)) {
          kend = jA + lastc * 30;
          k = kend;
          do {
            exitg1 = 0;
            if (k <= (kend + lastv) - 1) {
              if (A[k - 1] != 0.0F) {
                exitg1 = 1;
              } else {
                k++;
              }
            } else {
              lastc--;
              exitg1 = 2;
            }
          } while (exitg1 == 0);

          if (exitg1 == 1) {
            exitg2 = true;
          }
        }
      } else {
        lastv = 0;
        lastc = -1;
      }

      if (lastv > 0) {
        if (lastc + 1 != 0) {
          if (0 <= lastc) {
            memset(&work[0], 0, (unsigned int)((lastc + 1) * (int)sizeof(float)));
          }

          iy = 0;
          i1 = jA + 30 * lastc;
          for (kend = jA; kend <= i1; kend += 30) {
            ix = i_i;
            smax = 0.0F;
            pvt = (kend + lastv) - 1;
            for (k = kend; k <= pvt; k++) {
              smax += A[k - 1] * A[ix];
              ix++;
            }

            work[iy] += smax;
            iy++;
          }
        }

        if (!(-tau[i] == 0.0F)) {
          kend = 0;
          for (iy = 0; iy <= lastc; iy++) {
            if (work[kend] != 0.0F) {
              smax = work[kend] * -tau[i];
              ix = i_i;
              i1 = lastv + jA;
              for (pvt = jA; pvt < i1; pvt++) {
                A[pvt - 1] += A[ix] * smax;
                ix++;
              }
            }

            kend++;
            jA += 30;
          }
        }
      }

      A[i_i] = absxk;
    }

    for (iy = ip1; iy < 4; iy++) {
      smax = vn1[iy - 1];
      if (smax != 0.0F) {
        kend = i + 30 * (iy - 1);
        scale = fabsf(A[kend]) / smax;
        scale = 1.0F - scale * scale;
        if (scale < 0.0F) {
          scale = 0.0F;
        }

        absxk = smax / vn2[iy - 1];
        absxk = scale * (absxk * absxk);
        if (absxk <= 0.000345266977F) {
          smax = xnrm2(29 - i, A, kend + 2);
          vn1[iy - 1] = smax;
          vn2[iy - 1] = smax;
        } else {
          vn1[iy - 1] = smax * sqrtf(scale);
        }
      }
    }
  }
}

/*
 * File trailer for xgeqp3.c
 *
 * [EOF]
 */
