/*
 * File: xgeqp3.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 08-Jan-2021 09:44:36
 */

#ifndef XGEQP3_H
#define XGEQP3_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "My_Fit_types.h"

/* Function Declarations */
extern void xgeqp3(float A[90], float tau[3], int jpvt[3]);

#endif

/*
 * File trailer for xgeqp3.h
 *
 * [EOF]
 */
